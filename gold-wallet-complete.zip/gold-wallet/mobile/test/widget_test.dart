// Basic smoke test: the app should boot into the onboarding welcome screen
// when no wallet has been created/imported yet on this device.
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:gold_wallet/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('shows the Welcome screen on first launch', (tester) async {
    SharedPreferences.setMockInitialValues({});

    await tester.pumpWidget(const ProviderScope(child: GoldWalletApp()));
    await tester.pumpAndSettle();

    expect(find.text('Gold Wallet'), findsWidgets);
    expect(find.text('Create a New Wallet'), findsOneWidget);
  });
}
