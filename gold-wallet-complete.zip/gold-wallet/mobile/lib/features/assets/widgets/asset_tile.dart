// asset_tile.dart
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/models/crypto_asset.dart';
import '../../../core/network/icon_cache_service.dart';
import '../providers/asset_preferences_service.dart';

class AssetTile extends StatelessWidget {
  const AssetTile({
    super.key,
    required this.asset,
    required this.isFavorite,
    required this.onToggleFavorite,
    required this.onTap,
    this.currency = 'usd',
  });

  final CryptoAsset asset;
  final bool isFavorite;
  final VoidCallback onToggleFavorite;
  final VoidCallback onTap;
  final String currency; // 'usd' or 'inr'

  @override
  Widget build(BuildContext context) {
    final isUp = asset.change24hPercent >= 0;
    final price = currency == 'inr' ? asset.priceInr : asset.priceUsd;
    final symbolPrefix = currency == 'inr' ? '₹' : '\$';

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0x14D4AF37)),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: CachedNetworkImage(
                imageUrl: asset.logoUrl,
                width: 40,
                height: 40,
                fit: BoxFit.cover,
                placeholder: (context, url) => Container(
                  width: 40,
                  height: 40,
                  color: AppColors.surfaceElevated,
                ),
                errorWidget: (context, url, error) {
                  final fallback = IconCacheService.localFallback[asset.symbol];
                  if (fallback != null) {
                    return SvgPicture.asset(fallback, width: 40, height: 40);
                  }
                  return CircleAvatar(
                    radius: 20,
                    backgroundColor: AppColors.surfaceElevated,
                    child: Text(asset.symbol.substring(0, 1)),
                  );
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(asset.symbol,
                          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      const SizedBox(width: 6),
                      if (asset.isToken)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                            color: AppColors.goldMuted.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text('TOKEN', style: TextStyle(fontSize: 9)),
                        ),
                    ],
                  ),
                  Text(asset.network,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('$symbolPrefix${price.toStringAsFixed(price < 1 ? 4 : 2)}',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isUp ? Icons.arrow_drop_up_rounded : Icons.arrow_drop_down_rounded,
                      size: 16,
                      color: isUp ? AppColors.success : AppColors.danger,
                    ),
                    Text(
                      '${asset.change24hPercent.abs().toStringAsFixed(2)}%',
                      style: TextStyle(
                        fontSize: 12,
                        color: isUp ? AppColors.success : AppColors.danger,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(asset.balanceFormatted,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                Text('$symbolPrefix${asset.balanceUsdValue.toStringAsFixed(2)}',
                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
            IconButton(
              icon: Icon(
                isFavorite ? Icons.star_rounded : Icons.star_border_rounded,
                color: isFavorite ? AppColors.gold : AppColors.textSecondary,
                size: 20,
              ),
              onPressed: onToggleFavorite,
            ),
          ],
        ),
      ),
    );
  }
}
