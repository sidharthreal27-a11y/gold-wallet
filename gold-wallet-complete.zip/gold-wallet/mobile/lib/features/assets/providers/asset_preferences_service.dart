// asset_preferences_service.dart
import 'package:shared_preferences/shared_preferences.dart';

class AssetPreferencesService {
  static const _favoritesKey = 'favorite_symbols';
  static const _recentKey = 'recently_used_symbols';
  static const _maxRecent = 8;

  Future<Set<String>> getFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getStringList(_favoritesKey) ?? []).toSet();
  }

  Future<void> toggleFavorite(String symbol) async {
    final prefs = await SharedPreferences.getInstance();
    final current = (prefs.getStringList(_favoritesKey) ?? []).toSet();
    if (current.contains(symbol)) {
      current.remove(symbol);
    } else {
      current.add(symbol);
    }
    await prefs.setStringList(_favoritesKey, current.toList());
  }

  Future<List<String>> getRecentlyUsed() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_recentKey) ?? [];
  }

  /// Call whenever a user opens/sends/receives a specific asset, to surface
  /// it in the "Recently Used" row.
  Future<void> markUsed(String symbol) async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getStringList(_recentKey) ?? [];
    current.remove(symbol);
    current.insert(0, symbol);
    await prefs.setStringList(_recentKey, current.take(_maxRecent).toList());
  }
}
