// asset_list_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/crypto_asset.dart';
import '../../../core/network/coingecko_service.dart';
import 'asset_preferences_service.dart';

final coinGeckoServiceProvider = Provider((ref) => CoinGeckoService());
final assetPreferencesServiceProvider = Provider((ref) => AssetPreferencesService());

/// Which network/chain label each symbol displays with. USDT appears on
/// three chains in the requirements, so it's modeled as three distinct
/// CryptoAsset rows (see buildAssetList) rather than one merged row —
/// balances and deposit addresses genuinely differ per chain.
const Map<String, List<({String network, int? chainId, bool isToken})>> _assetNetworks = {
  'BTC': [(network: 'Bitcoin Network', chainId: null, isToken: false)],
  'ETH': [(network: 'Ethereum Network', chainId: 1, isToken: false)],
  'BNB': [(network: 'BNB Smart Chain', chainId: 56, isToken: false)],
  'MATIC': [(network: 'Polygon Network', chainId: 137, isToken: false)],
  'SOL': [(network: 'Solana Network', chainId: null, isToken: false)],
  'XRP': [(network: 'XRP Ledger', chainId: null, isToken: false)],
  'LTC': [(network: 'Litecoin Network', chainId: null, isToken: false)],
  'DOGE': [(network: 'Dogecoin Network', chainId: null, isToken: false)],
  'USDT': [
    (network: 'Ethereum Network (ERC-20)', chainId: 1, isToken: true),
    (network: 'BNB Smart Chain (BEP-20)', chainId: 56, isToken: true),
    (network: 'Tron Network (TRC-20)', chainId: null, isToken: true),
  ],
  'USDC': [(network: 'Ethereum Network (ERC-20)', chainId: 1, isToken: true)],
};

final assetListProvider = FutureProvider<List<CryptoAsset>>((ref) async {
  final service = ref.watch(coinGeckoServiceProvider);
  final markets = await service.getMarketsWithInr();

  final assets = <CryptoAsset>[];
  for (final entry in _assetNetworks.entries) {
    final symbol = entry.key;
    final market = markets[symbol];
    if (market == null) continue;

    for (final variant in entry.value) {
      assets.add(
        CryptoAsset(
          id: market['id'] as String,
          symbol: symbol,
          name: market['name'] as String,
          network: variant.network,
          chainId: variant.chainId,
          isToken: variant.isToken,
          logoUrl: market['image'] as String,
          priceUsd: (market['current_price'] as num?)?.toDouble() ?? 0,
          priceInr: (market['current_price_inr'] as num?)?.toDouble() ?? 0,
          change24hPercent: (market['price_change_percentage_24h'] as num?)?.toDouble() ?? 0,
          // Wire up real per-address balances via WalletBalanceProvider once
          // wallets are registered; placeholder zero until that's connected.
          balanceFormatted: '0',
          balanceUsdValue: 0,
        ),
      );
    }
  }
  return assets;
});

final trendingSymbolsProvider = FutureProvider<List<String>>((ref) async {
  final service = ref.watch(coinGeckoServiceProvider);
  return service.getTrendingSymbols();
});

final favoriteSymbolsProvider = FutureProvider<Set<String>>((ref) async {
  return ref.watch(assetPreferencesServiceProvider).getFavorites();
});

final recentlyUsedSymbolsProvider = FutureProvider<List<String>>((ref) async {
  return ref.watch(assetPreferencesServiceProvider).getRecentlyUsed();
});

enum AssetFilter { all, coins, tokens }

final assetFilterProvider = StateProvider<AssetFilter>((ref) => AssetFilter.all);
final assetSearchQueryProvider = StateProvider<String>((ref) => '');
