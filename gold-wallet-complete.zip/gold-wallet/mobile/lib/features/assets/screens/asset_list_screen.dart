// asset_list_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_theme.dart';
import '../providers/asset_list_provider.dart';
import '../widgets/asset_tile.dart';

class AssetListScreen extends ConsumerStatefulWidget {
  const AssetListScreen({super.key});

  @override
  ConsumerState<AssetListScreen> createState() => _AssetListScreenState();
}

class _AssetListScreenState extends ConsumerState<AssetListScreen> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final assetsAsync = ref.watch(assetListProvider);
    final trendingAsync = ref.watch(trendingSymbolsProvider);
    final favoritesAsync = ref.watch(favoriteSymbolsProvider);
    final recentAsync = ref.watch(recentlyUsedSymbolsProvider);
    final filter = ref.watch(assetFilterProvider);
    final query = ref.watch(assetSearchQueryProvider).toLowerCase();

    return Scaffold(
      appBar: AppBar(title: const Text('Assets')),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(assetListProvider);
          ref.invalidate(trendingSymbolsProvider);
        },
        child: assetsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator(color: AppColors.gold)),
          error: (err, _) => Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                'Couldn\'t load live prices. Showing cached data where available.\n$err',
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.textSecondary),
              ),
            ),
          ),
          data: (assets) {
            final favorites = favoritesAsync.value ?? {};
            final recent = recentAsync.value ?? [];
            final trending = trendingAsync.value ?? [];

            var filtered = assets.where((a) {
              final matchesQuery = query.isEmpty ||
                  a.symbol.toLowerCase().contains(query) ||
                  a.name.toLowerCase().contains(query);
              final matchesFilter = switch (filter) {
                AssetFilter.all => true,
                AssetFilter.coins => !a.isToken,
                AssetFilter.tokens => a.isToken,
              };
              return matchesQuery && matchesFilter;
            }).toList();

            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _SearchBar(controller: _searchController, ref: ref),
                const SizedBox(height: 16),
                _FilterChips(current: filter, ref: ref),
                const SizedBox(height: 20),

                if (query.isEmpty && trending.isNotEmpty) ...[
                  _SectionLabel('🔥 Trending'),
                  const SizedBox(height: 8),
                  _HorizontalSymbolChips(symbols: trending.take(6).toList()),
                  const SizedBox(height: 20),
                ],

                if (query.isEmpty && recent.isNotEmpty) ...[
                  _SectionLabel('Recently Used'),
                  const SizedBox(height: 8),
                  _HorizontalSymbolChips(symbols: recent),
                  const SizedBox(height: 20),
                ],

                if (query.isEmpty && favorites.isNotEmpty) ...[
                  _SectionLabel('⭐ Favorites'),
                  const SizedBox(height: 8),
                  ...filtered
                      .where((a) => favorites.contains(a.symbol))
                      .map((a) => AssetTile(
                            asset: a,
                            isFavorite: true,
                            onToggleFavorite: () => _toggleFavorite(a.symbol),
                            onTap: () => _openAsset(a),
                          )),
                  const SizedBox(height: 20),
                ],

                _SectionLabel(query.isEmpty ? 'All Assets' : 'Search Results'),
                const SizedBox(height: 8),
                if (filtered.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(
                      child: Text('No assets match your search.',
                          style: TextStyle(color: AppColors.textSecondary)),
                    ),
                  )
                else
                  ...filtered.map((a) => AssetTile(
                        asset: a,
                        isFavorite: favorites.contains(a.symbol),
                        onToggleFavorite: () => _toggleFavorite(a.symbol),
                        onTap: () => _openAsset(a),
                      )),
              ],
            );
          },
        ),
      ),
    );
  }

  void _toggleFavorite(String symbol) async {
    await ref.read(assetPreferencesServiceProvider).toggleFavorite(symbol);
    ref.invalidate(favoriteSymbolsProvider);
  }

  void _openAsset(dynamic asset) async {
    await ref.read(assetPreferencesServiceProvider).markUsed(asset.symbol as String);
    ref.invalidate(recentlyUsedSymbolsProvider);
    // Navigate to asset detail / send-receive flow from here.
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;
  @override
  Widget build(BuildContext context) =>
      Text(text, style: Theme.of(context).textTheme.titleMedium);
}

class _SearchBar extends StatelessWidget {
  const _SearchBar({required this.controller, required this.ref});
  final TextEditingController controller;
  final WidgetRef ref;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: (v) => ref.read(assetSearchQueryProvider.notifier).state = v,
      decoration: const InputDecoration(
        hintText: 'Search coin or token',
        prefixIcon: Icon(Icons.search_rounded, color: AppColors.textSecondary),
      ),
    );
  }
}

class _FilterChips extends StatelessWidget {
  const _FilterChips({required this.current, required this.ref});
  final AssetFilter current;
  final WidgetRef ref;

  @override
  Widget build(BuildContext context) {
    final options = [
      (AssetFilter.all, 'All'),
      (AssetFilter.coins, 'Coins'),
      (AssetFilter.tokens, 'Tokens'),
    ];
    return Row(
      children: options.map((o) {
        final selected = current == o.$1;
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(
            label: Text(o.$2),
            selected: selected,
            onSelected: (_) => ref.read(assetFilterProvider.notifier).state = o.$1,
            selectedColor: AppColors.gold.withOpacity(0.2),
            labelStyle: TextStyle(color: selected ? AppColors.gold : AppColors.textSecondary),
            backgroundColor: AppColors.surfaceElevated,
            side: BorderSide(color: selected ? AppColors.gold : Colors.transparent),
          ),
        );
      }).toList(),
    );
  }
}

class _HorizontalSymbolChips extends StatelessWidget {
  const _HorizontalSymbolChips({required this.symbols});
  final List<String> symbols;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 36,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: symbols.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) => Chip(
          label: Text(symbols[i]),
          backgroundColor: AppColors.surfaceElevated,
          side: const BorderSide(color: Color(0x22D4AF37)),
        ),
      ),
    );
  }
}
