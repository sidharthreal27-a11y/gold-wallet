// wallet_providers.dart
//
// Tracks which wallet (if any) is currently active on this device. Only the
// PUBLIC address is kept here / in SharedPreferences — key material always
// stays inside SecureStorageService, gated by biometrics.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/providers/core_providers.dart';
import '../../../core/security/wallet_service.dart';

const _activeWalletIdKey = 'active_wallet_id';

class ActiveWallet {
  final String walletId; // == the primary account address
  const ActiveWallet({required this.walletId});
}

class ActiveWalletNotifier extends AsyncNotifier<ActiveWallet?> {
  @override
  Future<ActiveWallet?> build() async {
    final prefs = await SharedPreferences.getInstance();
    final walletId = prefs.getString(_activeWalletIdKey);
    if (walletId == null) return null;
    return ActiveWallet(walletId: walletId);
  }

  Future<void> _persist(String? walletId) async {
    final prefs = await SharedPreferences.getInstance();
    if (walletId == null) {
      await prefs.remove(_activeWalletIdKey);
    } else {
      await prefs.setString(_activeWalletIdKey, walletId);
    }
  }

  /// Creates a brand-new wallet. Returns the plaintext mnemonic ONCE so the
  /// caller can push the backup screen; it is never stored by this notifier.
  Future<({String mnemonic, DerivedAccount account})> createWallet() async {
    final walletService = ref.read(walletServiceProvider);
    final result = await walletService.createWallet();
    await _persist(result.account.address);
    state = AsyncData(ActiveWallet(walletId: result.account.address));
    return result;
  }

  Future<DerivedAccount> importWallet(String mnemonic) async {
    final walletService = ref.read(walletServiceProvider);
    final account = await walletService.importWallet(mnemonic);
    await _persist(account.address);
    state = AsyncData(ActiveWallet(walletId: account.address));
    return account;
  }

  Future<void> removeWallet() async {
    final current = state.value;
    if (current != null) {
      await ref.read(walletServiceProvider).deleteWallet(current.walletId);
    }
    await _persist(null);
    state = const AsyncData(null);
  }
}

final activeWalletProvider = AsyncNotifierProvider<ActiveWalletNotifier, ActiveWallet?>(
  ActiveWalletNotifier.new,
);
