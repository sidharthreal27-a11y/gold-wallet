// wallet_shell_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_theme.dart';
import '../../assets/providers/asset_list_provider.dart';
import '../../assets/screens/asset_list_screen.dart';
import '../../scanpay/screens/scan_pay_screen.dart';
import '../../scanpay/screens/payment_uri_parser.dart';
import 'dashboard_screen.dart';
import 'settings_screen.dart';

/// Bottom-tab shell: Dashboard / Assets / Scan & Pay / Settings. This is the
/// main authenticated area of the app once a wallet exists on-device.
class WalletShellScreen extends ConsumerStatefulWidget {
  const WalletShellScreen({super.key});

  @override
  ConsumerState<WalletShellScreen> createState() => _WalletShellScreenState();
}

class _WalletShellScreenState extends ConsumerState<WalletShellScreen> {
  int _index = 0;

  void _onScanResult(BuildContext context, ParsedPaymentRequest request) {
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Recognized ${request.scheme ?? 'address'}: ${request.address}')),
    );
  }

  void _openScanner(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => ScanPayScreen(
          onPaymentDetected: (request) => _onScanResult(context, request),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final assetsAsync = ref.watch(assetListProvider);

    final pages = [
      assetsAsync.when(
        loading: () => const _DashboardLoading(),
        error: (err, _) => const DashboardScreen(totalBalanceUsd: '0.00', assets: []),
        data: (assets) {
          final total = assets.fold<double>(0, (sum, a) => sum + a.balanceUsdValue);
          final rows = assets
              .map((a) => AssetRow(
                    symbol: a.symbol,
                    name: a.name,
                    chainName: a.network,
                    balance: a.balanceFormatted,
                    fiatValue: a.balanceUsdValue.toStringAsFixed(2),
                    iconAsset: a.logoUrl,
                  ))
              .toList();
          return DashboardScreen(totalBalanceUsd: total.toStringAsFixed(2), assets: rows);
        },
      ),
      const AssetListScreen(),
      const SettingsScreen(),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openScanner(context),
        backgroundColor: AppColors.gold,
        foregroundColor: Colors.black,
        child: const Icon(Icons.qr_code_scanner_rounded),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 8,
        color: AppColors.surface,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _NavIcon(
              icon: Icons.dashboard_rounded,
              label: 'Dashboard',
              selected: _index == 0,
              onTap: () => setState(() => _index = 0),
            ),
            _NavIcon(
              icon: Icons.pie_chart_rounded,
              label: 'Assets',
              selected: _index == 1,
              onTap: () => setState(() => _index = 1),
            ),
            const SizedBox(width: 48),
            _NavIcon(
              icon: Icons.settings_rounded,
              label: 'Settings',
              selected: _index == 2,
              onTap: () => setState(() => _index = 2),
            ),
          ],
        ),
      ),
    );
  }
}

class _DashboardLoading extends StatelessWidget {
  const _DashboardLoading();
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator(color: AppColors.gold)),
    );
  }
}

class _NavIcon extends StatelessWidget {
  const _NavIcon({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.gold : AppColors.textSecondary;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(color: color, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
