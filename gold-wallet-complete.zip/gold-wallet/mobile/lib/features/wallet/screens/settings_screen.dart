// settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/providers/core_providers.dart';
import '../../../core/theme/theme_mode_provider.dart';
import '../providers/wallet_providers.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  List<String> _integrityWarnings = [];
  bool _checkedIntegrity = false;

  @override
  void initState() {
    super.initState();
    _runIntegrityCheck();
  }

  Future<void> _runIntegrityCheck() async {
    final warnings = await ref.read(deviceIntegrityServiceProvider).checkIntegrity();
    if (!mounted) return;
    setState(() {
      _integrityWarnings = warnings;
      _checkedIntegrity = true;
    });
  }

  Future<void> _confirmRemoveWallet() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.surfaceElevated,
        title: const Text('Remove wallet from this device?'),
        content: const Text(
          'This deletes the local copy of your keys. Make sure you\'ve backed '
          'up your recovery phrase — without it, funds cannot be recovered.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Remove', style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(activeWalletProvider.notifier).removeWallet();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (_checkedIntegrity && _integrityWarnings.isNotEmpty)
            Container(
              margin: const EdgeInsets.only(bottom: 20),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.danger.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.danger.withOpacity(0.4)),
              ),
              child: Text(
                _integrityWarnings.join('\n'),
                style: const TextStyle(color: AppColors.danger, fontSize: 12),
              ),
            ),
          _SectionLabel('Appearance'),
          Consumer(
            builder: (context, ref, _) {
              final mode = ref.watch(themeModeProvider);
              return Container(
                margin: const EdgeInsets.only(bottom: 20),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0x14D4AF37)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.brightness_6_rounded, color: AppColors.gold),
                    const SizedBox(width: 12),
                    const Expanded(child: Text('Theme')),
                    SegmentedButton<ThemeMode>(
                      segments: const [
                        ButtonSegment(value: ThemeMode.light, icon: Icon(Icons.light_mode_rounded)),
                        ButtonSegment(value: ThemeMode.dark, icon: Icon(Icons.dark_mode_rounded)),
                        ButtonSegment(
                            value: ThemeMode.system, icon: Icon(Icons.settings_suggest_rounded)),
                      ],
                      selected: {mode},
                      onSelectionChanged: (selection) =>
                          ref.read(themeModeProvider.notifier).setThemeMode(selection.first),
                    ),
                  ],
                ),
              );
            },
          ),
          _SectionLabel('Security'),
          _SettingsTile(icon: Icons.fingerprint_rounded, title: 'Biometric unlock', onTap: () {}),
          _SettingsTile(icon: Icons.pin_rounded, title: 'Change app PIN', onTap: () {}),
          _SettingsTile(
              icon: Icons.verified_user_rounded, title: 'Two-factor authentication', onTap: () {}),
          _SettingsTile(icon: Icons.devices_rounded, title: 'Device management', onTap: () {}),
          _SettingsTile(
              icon: Icons.history_rounded, title: 'Login activity history', onTap: () {}),
          _SettingsTile(
              icon: Icons.shield_rounded, title: 'Backup recovery phrase', onTap: () {}),
          const SizedBox(height: 20),
          _SectionLabel('Notifications'),
          _SettingsTile(
              icon: Icons.notifications_active_rounded, title: 'Price alerts', onTap: () {}),
          _SettingsTile(
              icon: Icons.swap_horiz_rounded, title: 'Transaction alerts', onTap: () {}),
          const SizedBox(height: 20),
          _SectionLabel('Support'),
          _SettingsTile(icon: Icons.chat_bubble_outline_rounded, title: 'Chat with support', onTap: () {}),
          _SettingsTile(icon: Icons.help_outline_rounded, title: 'Help center & FAQ', onTap: () {}),
          const SizedBox(height: 20),
          _SectionLabel('Wallet'),
          _SettingsTile(
            icon: Icons.delete_outline_rounded,
            title: 'Remove wallet from this device',
            titleColor: AppColors.danger,
            onTap: _confirmRemoveWallet,
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text, style: Theme.of(context).textTheme.titleMedium),
      );
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.titleColor,
  });

  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final Color? titleColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x14D4AF37)),
      ),
      child: ListTile(
        leading: Icon(icon, color: titleColor ?? AppColors.gold),
        title: Text(title, style: TextStyle(color: titleColor)),
        trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textSecondary),
        onTap: onTap,
      ),
    );
  }
}
