// app_router.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../features/onboarding/screens/welcome_screen.dart';
import '../features/onboarding/screens/import_wallet_screen.dart';
import '../features/onboarding/screens/backup_seed_screen.dart';
import '../features/wallet/providers/wallet_providers.dart';
import '../features/wallet/screens/wallet_shell_screen.dart';

/// Route names, kept as constants so screens can navigate by name instead of
/// hardcoded path strings.
class AppRoutes {
  static const welcome = 'welcome';
  static const createWallet = 'create-wallet';
  static const importWallet = 'import-wallet';
  static const backupSeed = 'backup-seed';
  static const home = 'home';
}

final goRouterProvider = Provider<GoRouter>((ref) {
  final refreshNotifier = _GoRouterRefreshNotifier();
  ref.listen(activeWalletProvider, (previous, next) => refreshNotifier.notify());

  return GoRouter(
    initialLocation: '/',
    redirect: (context, state) {
      final activeWallet = ref.read(activeWalletProvider);
      // While the persisted wallet id is still loading, don't redirect yet.
      if (activeWallet.isLoading) return null;

      final hasWallet = activeWallet.value != null;
      final onOnboardingRoute = state.matchedLocation == '/' ||
          state.matchedLocation == '/import' ||
          state.matchedLocation.startsWith('/backup');

      if (hasWallet && onOnboardingRoute) return '/home';
      if (!hasWallet && !onOnboardingRoute) return '/';
      return null;
    },
    refreshListenable: refreshNotifier,
    routes: [
      GoRoute(
        path: '/',
        name: AppRoutes.welcome,
        builder: (context, state) => WelcomeScreen(
          onCreateWallet: () => context.pushNamed(AppRoutes.createWallet),
          onImportWallet: () => context.pushNamed(AppRoutes.importWallet),
        ),
      ),
      GoRoute(
        path: '/create',
        name: AppRoutes.createWallet,
        builder: (context, state) => const _CreateWalletFlow(),
      ),
      GoRoute(
        path: '/import',
        name: AppRoutes.importWallet,
        builder: (context, state) => Consumer(
          builder: (context, ref, _) => ImportWalletScreen(
            onImport: (mnemonic) async {
              try {
                await ref.read(activeWalletProvider.notifier).importWallet(mnemonic);
                if (context.mounted) context.goNamed(AppRoutes.home);
                return null;
              } catch (e) {
                return e is ArgumentError ? e.message.toString() : 'Import failed: $e';
              }
            },
          ),
        ),
      ),
      GoRoute(
        path: '/home',
        name: AppRoutes.home,
        builder: (context, state) => const WalletShellScreen(),
      ),
    ],
  );
});

/// Generates a fresh wallet as soon as this screen is entered, then shows the
/// mandatory backup screen before allowing the user into the app.
class _CreateWalletFlow extends ConsumerStatefulWidget {
  const _CreateWalletFlow();

  @override
  ConsumerState<_CreateWalletFlow> createState() => _CreateWalletFlowState();
}

class _CreateWalletFlowState extends ConsumerState<_CreateWalletFlow> {
  String? _mnemonic;
  String? _error;

  @override
  void initState() {
    super.initState();
    _generate();
  }

  Future<void> _generate() async {
    try {
      final result = await ref.read(activeWalletProvider.notifier).createWallet();
      if (!mounted) return;
      setState(() => _mnemonic = result.mnemonic);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'Could not create wallet: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(body: Center(child: Text(_error!)));
    }
    if (_mnemonic == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return BackupSeedScreen(
      mnemonic: _mnemonic!,
      onConfirmed: () => context.goNamed(AppRoutes.home),
    );
  }
}

/// Bridges Riverpod state changes to GoRouter's `refreshListenable`, so the
/// router re-evaluates `redirect` whenever the active-wallet state changes
/// (e.g. right after createWallet()/importWallet()/removeWallet()).
class _GoRouterRefreshNotifier extends ChangeNotifier {
  void notify() => notifyListeners();
}
