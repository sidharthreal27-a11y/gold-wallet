// core_providers.dart
//
// App-wide singletons (security services, etc.) wired through Riverpod so
// every feature reaches them the same way instead of constructing its own
// instance.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../security/biometric_service.dart';
import '../security/secure_storage_service.dart';
import '../security/wallet_service.dart';
import '../security/device_integrity_service.dart';

final biometricServiceProvider = Provider<BiometricService>((ref) {
  return BiometricService();
});

final secureStorageServiceProvider = Provider<SecureStorageService>((ref) {
  return SecureStorageService(biometricService: ref.watch(biometricServiceProvider));
});

final walletServiceProvider = Provider<WalletService>((ref) {
  return WalletService(ref.watch(secureStorageServiceProvider));
});

final deviceIntegrityServiceProvider = Provider<DeviceIntegrityService>((ref) {
  return DeviceIntegrityService();
});
