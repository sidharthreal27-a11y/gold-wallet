// coingecko_service.dart
//
// Fetches market data (price, 24h change, official logo URL) for supported
// assets. Calls go through the backend's /api/v1/prices proxy in production
// (see backend/src/controllers/prices.controller.js) so a paid CoinGecko key
// isn't embedded in the shipped app; this class can point at either that
// proxy or CoinGecko directly for local development.

import 'dart:convert';
import 'package:dio/dio.dart';

class CoinGeckoService {
  CoinGeckoService({Dio? dio, String? baseUrl})
      : _dio = dio ?? Dio(),
        _baseUrl = baseUrl ?? 'https://api.coingecko.com/api/v3';

  final Dio _dio;
  final String _baseUrl;

  /// Maps our internal symbols to CoinGecko coin ids — needed because
  /// CoinGecko's `/coins/markets` endpoint takes ids, not ticker symbols
  /// (symbols aren't unique across all listed coins).
  static const Map<String, String> symbolToId = {
    'BTC': 'bitcoin',
    'ETH': 'ethereum',
    'BNB': 'binancecoin',
    'MATIC': 'matic-network',
    'SOL': 'solana',
    'USDT': 'tether',
    'USDC': 'usd-coin',
    'XRP': 'ripple',
    'LTC': 'litecoin',
    'DOGE': 'dogecoin',
  };

  /// Returns raw CoinGecko market objects (id, symbol, name, image,
  /// current_price, price_change_percentage_24h, ...) keyed by our symbol.
  Future<Map<String, Map<String, dynamic>>> getMarkets({
    List<String>? symbols,
    String vsCurrency = 'usd',
  }) async {
    final targetSymbols = symbols ?? symbolToId.keys.toList();
    final ids = targetSymbols.map((s) => symbolToId[s]).whereType<String>().join(',');

    final response = await _dio.get(
      '$_baseUrl/coins/markets',
      queryParameters: {
        'vs_currency': vsCurrency,
        'ids': ids,
        'order': 'market_cap_desc',
        'price_change_percentage': '24h',
      },
    );

    final list = (response.data as List).cast<Map<String, dynamic>>();
    final bySymbol = <String, Map<String, dynamic>>{};
    for (final coin in list) {
      bySymbol[(coin['symbol'] as String).toUpperCase()] = coin;
    }
    return bySymbol;
  }

  /// Convenience call that fetches both USD and INR pricing in two requests
  /// and merges `current_price_inr` onto each USD market object, so callers
  /// building a CryptoAsset only need to look at one map.
  Future<Map<String, Map<String, dynamic>>> getMarketsWithInr({List<String>? symbols}) async {
    final usd = await getMarkets(symbols: symbols, vsCurrency: 'usd');
    final inr = await getMarkets(symbols: symbols, vsCurrency: 'inr');
    for (final entry in usd.entries) {
      final inrPrice = inr[entry.key]?['current_price'];
      entry.value['current_price_inr'] = inrPrice;
    }
    return usd;
  }

  /// Trending coins (CoinGecko's own trending-search endpoint) for the
  /// "Trending" section of the asset list.
  Future<List<String>> getTrendingSymbols() async {
    final response = await _dio.get('$_baseUrl/search/trending');
    final coins = (response.data['coins'] as List).cast<Map<String, dynamic>>();
    return coins.map((c) => (c['item']['symbol'] as String).toUpperCase()).toList();
  }
}
