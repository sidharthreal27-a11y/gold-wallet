// icon_cache_service.dart
//
// cached_network_image already persists to disk (via flutter_cache_manager)
// so a logo shown once keeps working offline. This service just prewarms
// that cache right after fetching market data, and provides a local vector
// fallback for the handful of core coins in case the network/logo URL is
// unavailable on first launch (e.g. first run with no connectivity yet).

import 'package:flutter/widgets.dart';
import 'package:cached_network_image/cached_network_image.dart';

class IconCacheService {
  /// Local fallback assets bundled with the app — used only until the real
  /// CoinGecko logo has been fetched+cached at least once.
  static const Map<String, String> localFallback = {
    'BTC': 'assets/icons/btc.svg',
    'ETH': 'assets/icons/eth.svg',
    'BNB': 'assets/icons/bnb.svg',
    'MATIC': 'assets/icons/polygon.svg',
    'SOL': 'assets/icons/sol.svg',
    'USDT': 'assets/icons/usdt.svg',
    'USDC': 'assets/icons/usdc.svg',
    'XRP': 'assets/icons/xrp.svg',
    'LTC': 'assets/icons/ltc.svg',
    'DOGE': 'assets/icons/doge.svg',
  };

  /// Call once after fetching market data (e.g. in the asset list provider)
  /// so logos are already on disk before the user scrolls to them, and so
  /// the list keeps working next time the app opens offline.
  Future<void> prewarm(BuildContext context, List<String> logoUrls) async {
    for (final url in logoUrls) {
      if (url.isEmpty) continue;
      try {
        await precacheImage(CachedNetworkImageProvider(url), context);
      } catch (_) {
        // Non-fatal — the widget-level CachedNetworkImage will retry and
        // fall back to the local asset via errorWidget.
      }
    }
  }
}
