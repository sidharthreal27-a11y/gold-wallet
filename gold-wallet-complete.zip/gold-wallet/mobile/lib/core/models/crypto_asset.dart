// crypto_asset.dart
//
// Unified model for anything shown in the asset list: native coins (BTC, ETH,
// BNB, SOL, XRP, LTC, DOGE) and tokens (USDT/USDC across their chains).
// `isToken` + `network` distinguish e.g. "USDT on Ethereum" from "USDT on BNB
// Chain" as genuinely separate rows, since balances/addresses differ per chain.

class CryptoAsset {
  final String id; // CoinGecko id, e.g. "bitcoin", "tether"
  final String symbol; // "BTC", "USDT"
  final String name; // "Bitcoin", "Tether USD"
  final String network; // "Bitcoin Network", "Ethereum Network", "BNB Smart Chain", ...
  final int? chainId; // null for non-EVM / native chains like BTC, SOL
  final bool isToken; // true for USDT/USDC-style tokens, false for native coins
  final String logoUrl; // official logo, from CoinGecko's `image` field
  final double priceUsd;
  final double priceInr;
  final double change24hPercent;
  final String balanceFormatted; // e.g. "0.0042"
  final double balanceUsdValue;

  const CryptoAsset({
    required this.id,
    required this.symbol,
    required this.name,
    required this.network,
    required this.logoUrl,
    required this.priceUsd,
    required this.priceInr,
    required this.change24hPercent,
    required this.balanceFormatted,
    required this.balanceUsdValue,
    this.chainId,
    this.isToken = false,
  });

  CryptoAsset copyWith({
    double? priceUsd,
    double? priceInr,
    double? change24hPercent,
    String? balanceFormatted,
    double? balanceUsdValue,
  }) {
    return CryptoAsset(
      id: id,
      symbol: symbol,
      name: name,
      network: network,
      logoUrl: logoUrl,
      chainId: chainId,
      isToken: isToken,
      priceUsd: priceUsd ?? this.priceUsd,
      priceInr: priceInr ?? this.priceInr,
      change24hPercent: change24hPercent ?? this.change24hPercent,
      balanceFormatted: balanceFormatted ?? this.balanceFormatted,
      balanceUsdValue: balanceUsdValue ?? this.balanceUsdValue,
    );
  }

  factory CryptoAsset.fromCoinGeckoMarket(
    Map<String, dynamic> json, {
    required String network,
    int? chainId,
    bool isToken = false,
    String balanceFormatted = '0',
    double balanceUsdValue = 0,
  }) {
    return CryptoAsset(
      id: json['id'] as String,
      symbol: (json['symbol'] as String).toUpperCase(),
      name: json['name'] as String,
      network: network,
      chainId: chainId,
      isToken: isToken,
      logoUrl: json['image'] as String,
      priceUsd: (json['current_price'] as num?)?.toDouble() ?? 0,
      priceInr: 0, // filled in by a separate vs_currency=inr call, see CoinGeckoService
      change24hPercent: (json['price_change_percentage_24h'] as num?)?.toDouble() ?? 0,
      balanceFormatted: balanceFormatted,
      balanceUsdValue: balanceUsdValue,
    );
  }
}
