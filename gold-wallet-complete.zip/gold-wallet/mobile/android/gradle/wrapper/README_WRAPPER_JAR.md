# Missing binary: gradle-wrapper.jar

This folder needs a compiled `gradle-wrapper.jar` (a small binary published by
Gradle) next to `gradle-wrapper.properties`. It can't be generated as text, and
this project was assembled without network access, so it isn't included here.

Fix (pick one, both take a few seconds):

1. **Simplest** — from the `mobile/` directory, run:
   ```
   flutter create --platforms=android .
   ```
   This safely regenerates only the missing Android platform files (it will
   NOT touch your lib/ code) using your local Flutter SDK's own Gradle
   wrapper, which is guaranteed to match your installed Flutter/AGP version.

2. Or, if you have Gradle installed globally:
   ```
   cd android && gradle wrapper --gradle-version 8.6
   ```

3. Or just open `mobile/` in Android Studio — it detects the missing wrapper
   jar and offers to regenerate it automatically on project sync.

After that, `flutter pub get` and `flutter build apk --release` will work as
normal.
