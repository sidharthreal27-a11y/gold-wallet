# Flutter wrapper classes
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# Bouncy Castle / crypto primitives used transitively by bip32/pointycastle-backed packages
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**

# web3dart / http client internals
-keep class com.google.gson.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
